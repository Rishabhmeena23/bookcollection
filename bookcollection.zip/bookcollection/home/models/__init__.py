from .model import Product
from .category import Categorie
from .customer import Customer